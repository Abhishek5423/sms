

class user{
	public:
	Students* user_student;
	Teachers* user_teacher;
	
	void null(){
		user_student=0;
		user_teacher=0;
	}
};
